# Python Activity-Based Learning (ABL) Assignment

**Course:** Python Programming  
**Institution:** Dr. RVR NRI Institute of Technology  
**Assignment:** Python Activity-Based Learning  
**Selected case studies:** 10

## Folder contents
Each `case_XX_*` folder contains:
- `problem_statement.md`
- `objectives_assumptions.md`
- `algorithm.md`
- `flowchart.txt`
- `pseudocode.txt`
- `solution.py`
- `test_cases.md`
- `sample_output.txt`
- `output_screenshot.png`

`Consolidated_Project_Report.pdf` contains the report for all ten case studies.

## How to run
1. Install Python 3.
2. Open a terminal in the relevant case folder.
3. Run `python solution.py` (or `python3 solution.py`).
4. Compare the output with `sample_output.txt`.

## GitHub submission
Create a GitHub repository named `Python-Activity-Based-Learning`, upload the contents of this folder, and submit its URL to your Python Programming faculty member/Lab Mentor.

## Important academic note
The circular asks students to complete the work independently and be ready to explain and demonstrate each program. Review the assumptions, run the code yourself, and personalize the work based on your faculty's instructions before submission.
