# Test Cases

| Test | Expected result |
|---|---|
| Asha | Eligible, rank 2 |
| Bala | Eligible, rank 3 |
| Charan | Ineligible: subject mark below 60 |
| Divya | Ineligible: attendance below 75 |
| Esha | Eligible, rank 1 |

## Expected summary
Esha ranks 1, Asha ranks 2, Bala ranks 3. Charan and Divya are ineligible.
