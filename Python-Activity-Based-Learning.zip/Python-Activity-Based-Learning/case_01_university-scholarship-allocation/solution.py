# Case Study 01: University Scholarship Allocation
applicants = [
    ("Asha", [82, 78, 91], 88, 180000),
    ("Bala", [76, 72, 80], 92, 200000),
    ("Charan", [90, 55, 94], 95, 150000),
    ("Divya", [75, 80, 77], 70, 120000),
    ("Esha", [85, 84, 86], 90, 240000),
]

eligible = []
for name, marks, attendance, income in applicants:
    aggregate = sum(marks) / len(marks)
    reasons = []
    if aggregate < 75:
        reasons.append("aggregate below 75")
    if min(marks) < 60:
        reasons.append("subject mark below 60")
    if attendance < 75:
        reasons.append("attendance below 75")
    if income > 250000:
        reasons.append("income above Rs. 250000")
    if not reasons:
        eligible.append((name, aggregate, attendance, income))
    else:
        print(f"{name}: Not eligible ({', '.join(reasons)})")

eligible.sort(key=lambda item: (-item[1], -item[2], item[3], item[0]))
print("\nScholarship ranking:")
for rank, (name, aggregate, attendance, income) in enumerate(eligible, 1):
    print(f"{rank}. {name} | Aggregate: {aggregate:.2f}% | Attendance: {attendance}% | Income: Rs. {income}")
