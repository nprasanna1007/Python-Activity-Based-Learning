# Objectives
1. Validate applicant data.
2. Apply all scholarship eligibility rules.
3. Rank eligible applicants by aggregate marks, then attendance, then lower family income.

# Assumptions
- Marks are percentages from 0 to 100.
- Eligibility requires aggregate >= 75, every subject >= 60, attendance >= 75%, and annual family income <= Rs. 250000.
- Ties are resolved by higher attendance, then lower income, then applicant name alphabetically.
