# Algorithm
1. Start.
2. Read applicant records.
3. Validate marks, attendance, and income ranges.
4. Check aggregate, minimum subject marks, attendance, and income conditions.
5. Store eligible applicants.
6. Sort eligible applicants using the tie-breaking rules.
7. Display eligible ranking and ineligible reasons.
8. Stop.
