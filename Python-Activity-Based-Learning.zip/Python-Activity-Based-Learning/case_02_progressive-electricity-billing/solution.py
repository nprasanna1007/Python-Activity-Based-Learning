# Case Study 02: Progressive Electricity Billing
monthly_units = [80, 95, 145, 260]
fixed_charge = 50

def energy_charge(units):
    if units <= 100:
        return units * 2
    elif units <= 200:
        return 100 * 2 + (units - 100) * 3
    return 100 * 2 + 100 * 3 + (units - 200) * 5

bills = []
for month, units in enumerate(monthly_units, 1):
    if units < 0:
        print(f"Month {month}: invalid consumption")
        bills.append(0)
        continue
    energy = energy_charge(units)
    surcharge = energy * 0.05
    subtotal = energy + fixed_charge + surcharge
    rebate = subtotal * 0.10 if units < 100 else 0
    bill = subtotal - rebate
    bills.append(bill)
    print(f"Month {month}: {units} units | Energy Rs. {energy:.2f} | Rebate Rs. {rebate:.2f} | Bill Rs. {bill:.2f}")

print("\nUnusual increases (above 30%):")
found = False
for i in range(1, len(bills)):
    if bills[i - 1] > 0:
        increase = (bills[i] - bills[i - 1]) / bills[i - 1] * 100
        if increase > 30:
            print(f"Month {i + 1}: increase of {increase:.2f}%")
            found = True
if not found:
    print("No unusual increases")
