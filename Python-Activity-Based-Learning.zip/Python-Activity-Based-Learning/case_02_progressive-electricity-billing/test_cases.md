# Test Cases

| Test | Expected result |
|---|---|
| 80 units | Bill Rs. 196.20 |
| 95 units | Bill Rs. 224.55 |
| 145 units | Bill Rs. 401.75 |
| 260 units | Bill Rs. 890.00 |

## Expected summary
For the sample sequence, the calculated bills are Rs. 196.20, Rs. 224.55, Rs. 401.75, and Rs. 890.00. Increases above 30% are flagged.
