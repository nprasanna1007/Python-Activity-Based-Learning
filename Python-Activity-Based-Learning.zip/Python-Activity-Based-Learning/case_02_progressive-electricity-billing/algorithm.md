# Algorithm
1. Start.
2. Read monthly consumption values.
3. Reject negative consumption.
4. Calculate slab-wise energy charge.
5. Add fixed charge and surcharge.
6. Apply rebate when applicable.
7. Compare each bill with the previous month's bill.
8. Print bills and unusual increase alerts.
9. Stop.
