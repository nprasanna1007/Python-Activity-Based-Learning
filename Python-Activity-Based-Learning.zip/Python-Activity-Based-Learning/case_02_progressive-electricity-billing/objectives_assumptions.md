# Objectives
1. Calculate energy charges using progressive slabs.
2. Add fixed charges and surcharge, then apply an eligible rebate.
3. Compare monthly bills and flag increases above 30%.

# Assumptions
- First 100 units cost Rs. 2 per unit; next 100 units cost Rs. 3; units above 200 cost Rs. 5.
- Fixed charge is Rs. 50; surcharge is 5% of energy charges.
- A 10% rebate on the subtotal is given when consumption is below 100 units.
- An increase above 30% compared with the previous month is unusual.
