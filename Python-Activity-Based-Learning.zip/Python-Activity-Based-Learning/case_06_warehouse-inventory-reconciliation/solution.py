# Case Study 06: Warehouse Inventory Reconciliation
# Record format: (product, opening, received, dispatched, recorded_closing)
records = [
    ("Pens", 40, 30, 25, 45),
    ("Notebooks", 60, 20, 35, 40),
    ("Markers", 25, 15, 10, 32),
]
target_stock = 50

print("WAREHOUSE STOCK RECONCILIATION")
for product, opening, received, dispatched, closing in records:
    if min(opening, received, dispatched, closing) < 0:
        print(f"{product}: invalid negative quantity")
        continue
    expected = opening + received - dispatched
    difference = closing - expected
    replenishment = max(0, target_stock - closing)
    status = "OK" if difference == 0 else f"DISCREPANCY ({difference:+d} units)"
    print(f"{product}: expected={expected}, recorded={closing}, {status}, replenish={replenishment}")
