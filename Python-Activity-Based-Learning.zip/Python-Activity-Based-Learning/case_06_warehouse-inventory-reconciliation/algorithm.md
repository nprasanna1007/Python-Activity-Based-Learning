# Algorithm
1. Start.
2. Read product stock records.
3. Validate all quantities are non-negative.
4. Calculate expected closing stock.
5. Compare it with recorded closing stock.
6. Report discrepancy if values differ.
7. Calculate replenishment needed to reach target stock.
8. Stop.
