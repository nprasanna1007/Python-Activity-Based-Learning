# Test Cases

| Test | Expected result |
|---|---|
| Pens | Expected 45, recorded 45, OK, replenish 5 |
| Notebooks | Expected 45, recorded 40, discrepancy -5, replenish 10 |
| Markers | Expected 30, recorded 32, discrepancy +2, replenish 18 |

## Expected summary
Pens match expected stock; Notebooks have a shortage discrepancy of 5; Markers have a surplus discrepancy of 2.
