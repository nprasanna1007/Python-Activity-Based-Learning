# Objectives
1. Calculate expected closing stock.
2. Compare expected and recorded closing quantities.
3. Calculate discrepancies and replenishment to a target level.

# Assumptions
- Expected closing stock = opening + received - dispatched.
- Negative stock movements are invalid.
- A discrepancy exists when recorded closing stock differs from expected stock.
- Target stock level is 50 units for each product.
