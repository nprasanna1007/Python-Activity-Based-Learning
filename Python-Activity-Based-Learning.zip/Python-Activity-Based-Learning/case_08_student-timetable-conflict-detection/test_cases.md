# Test Cases

| Test | Expected result |
|---|---|
| Python and Maths | Group CSM-A overlap on Monday 10-11 |
| Python and English | Lab1 overlap on Monday 11? No: Python ends at 11, English starts at 11 |
| Physics | No conflict because Tuesday |

## Expected summary
Python and Maths are flagged for group CSM-A overlap; back-to-back classes that only touch at an endpoint are not considered overlapping.
