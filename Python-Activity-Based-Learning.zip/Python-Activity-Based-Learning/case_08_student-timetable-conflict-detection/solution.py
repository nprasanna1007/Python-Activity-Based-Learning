# Case Study 08: Student Timetable Conflict Detection
# Tuple: (course, day, start_hour, end_hour, room, group)
schedule = [
    ("Python", "Mon", 9, 11, "Lab1", "CSM-A"),
    ("Maths", "Mon", 10, 12, "Room2", "CSM-A"),
    ("English", "Mon", 11, 12, "Lab1", "CSM-B"),
    ("Physics", "Tue", 9, 10, "Room2", "CSM-A"),
]

valid = True
for course, day, start, end, room, group in schedule:
    if start < 0 or end > 23 or start >= end:
        print(f"Invalid time interval for {course}")
        valid = False

if valid:
    conflicts = []
    for i in range(len(schedule)):
        for j in range(i + 1, len(schedule)):
            a = schedule[i]
            b = schedule[j]
            same_day = a[1] == b[1]
            overlap = a[2] < b[3] and b[2] < a[3]
            if same_day and overlap:
                if a[4] == b[4]:
                    conflicts.append(f"{a[0]} and {b[0]}: room {a[4]} conflict")
                if a[5] == b[5]:
                    conflicts.append(f"{a[0]} and {b[0]}: group {a[5]} conflict")
    if conflicts:
        print("TIMETABLE CONFLICTS")
        for conflict in conflicts:
            print("-", conflict)
    else:
        print("No timetable conflicts found.")
