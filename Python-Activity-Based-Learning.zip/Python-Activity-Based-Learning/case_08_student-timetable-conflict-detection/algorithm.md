# Algorithm
1. Start.
2. Read schedule tuples.
3. Validate start and end hours.
4. Compare every pair of classes.
5. If same day and times overlap, check room and group conflicts.
6. Report each conflict once.
7. Display validation result.
8. Stop.
