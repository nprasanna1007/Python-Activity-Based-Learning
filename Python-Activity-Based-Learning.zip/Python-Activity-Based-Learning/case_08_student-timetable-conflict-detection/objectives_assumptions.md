# Objectives
1. Represent each class as a tuple.
2. Detect overlapping classes in the same room or for the same course group.
3. Report timetable conflicts.

# Assumptions
- Schedule tuple format is (course, day, start_hour, end_hour, room, group).
- A class overlaps another when the day matches and start of one is earlier than the end of the other.
- Rooms and groups cannot have overlapping classes.
- Hours are integers in 0-23 and end time must be greater than start time.
