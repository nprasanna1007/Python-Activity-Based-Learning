# Test Cases

| Test | Expected result |
|---|---|
| Asha | Exam 1 64.33; Exam 2 72.00; change +7.67; Good |
| Bala | Exam 1 54.33; Exam 2 54.67; change +0.33; Needs Improvement |
| Invalid mark | Invalid score detected |

## Expected summary
Student averages, changes, performance categories, and subject averages are printed. Weak subjects are those averaging below 50.
