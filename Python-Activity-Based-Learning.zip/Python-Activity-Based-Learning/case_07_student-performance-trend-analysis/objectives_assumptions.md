# Objectives
1. Calculate student averages and changes between exams.
2. Identify subjects with average marks below the threshold.
3. Classify performance using the final average.

# Assumptions
- Scores are percentages from 0 to 100.
- Each row represents one student and each column a subject for one exam.
- Weak subject threshold is 50 average marks.
- Final average >= 75 is Excellent; >= 60 is Good; otherwise Needs Improvement.
