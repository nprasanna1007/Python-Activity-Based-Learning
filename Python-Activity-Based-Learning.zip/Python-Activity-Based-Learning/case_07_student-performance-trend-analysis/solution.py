# Case Study 07: Student Performance Trend Analysis
students = ["Asha", "Bala", "Charan"]
subjects = ["Python", "Maths", "English"]
exam1 = [[65, 58, 70], [48, 55, 60], [80, 76, 72]]
exam2 = [[78, 64, 74], [52, 49, 63], [84, 81, 75]]

all_scores = exam1 + exam2
if any(mark < 0 or mark > 100 for row in all_scores for mark in row):
    print("Invalid score detected.")
else:
    print("STUDENT PERFORMANCE TRENDS")
    for i, name in enumerate(students):
        avg1 = sum(exam1[i]) / len(subjects)
        avg2 = sum(exam2[i]) / len(subjects)
        change = avg2 - avg1
        if avg2 >= 75:
            level = "Excellent"
        elif avg2 >= 60:
            level = "Good"
        else:
            level = "Needs Improvement"
        print(f"{name}: Exam 1={avg1:.2f}, Exam 2={avg2:.2f}, Change={change:+.2f}, {level}")

    print("\nSubject averages across both exams:")
    for j, subject in enumerate(subjects):
        total = 0
        count = 0
        for row in all_scores:
            total += row[j]
            count += 1
        average = total / count
        status = "WEAK SUBJECT" if average < 50 else "Within threshold"
        print(f"{subject}: {average:.2f} - {status}")
