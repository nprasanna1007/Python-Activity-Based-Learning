# Algorithm
1. Start.
2. Read scores for two exams.
3. Validate all scores.
4. Calculate each student's average for both exams.
5. Calculate improvement or decline.
6. Calculate subject averages across students.
7. Identify weak subjects and classify students.
8. Display the analysis.
9. Stop.
