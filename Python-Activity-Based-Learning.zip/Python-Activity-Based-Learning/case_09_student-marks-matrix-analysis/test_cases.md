# Test Cases

| Test | Expected result |
|---|---|
| Divya | Total 270, average 90.00 |
| Top performer | Divya with 270 marks |
| Invalid mark >100 | Invalid marks matrix |

## Expected summary
Divya is the top performer with 270 marks. Subject-wise averages and any averages below 50 are displayed.
