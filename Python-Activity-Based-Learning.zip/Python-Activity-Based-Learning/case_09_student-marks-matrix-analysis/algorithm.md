# Algorithm
1. Start.
2. Read student names, subjects, and marks matrix.
3. Validate matrix dimensions and marks.
4. Calculate totals and averages for each student.
5. Calculate average for each subject.
6. Find the highest total and low-average subjects.
7. Display results.
8. Stop.
