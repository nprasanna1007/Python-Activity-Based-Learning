# Case Study 09: Student Marks Matrix Analysis
students = ["Asha", "Bala", "Charan", "Divya"]
subjects = ["Python", "Maths", "English"]
marks = [
    [85, 78, 82],
    [66, 72, 70],
    [45, 48, 55],
    [92, 88, 90],
]

if any(len(row) != len(subjects) for row in marks) or any(
    mark < 0 or mark > 100 for row in marks for mark in row
):
    print("Invalid marks matrix.")
else:
    totals = []
    print("STUDENT-WISE RESULTS")
    for i, name in enumerate(students):
        total = sum(marks[i])
        average = total / len(subjects)
        totals.append(total)
        print(f"{name}: total={total}, average={average:.2f}")

    print("\nSUBJECT-WISE AVERAGES")
    for j, subject in enumerate(subjects):
        column_total = 0
        for i in range(len(students)):
            column_total += marks[i][j]
        average = column_total / len(students)
        label = "LOW AVERAGE" if average < 50 else "OK"
        print(f"{subject}: {average:.2f} ({label})")

    top_index = totals.index(max(totals))
    print(f"\nTop performer: {students[top_index]} with {totals[top_index]} marks")
