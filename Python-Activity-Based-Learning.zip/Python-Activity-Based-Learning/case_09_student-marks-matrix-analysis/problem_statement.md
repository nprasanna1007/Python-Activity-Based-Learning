# Case Study 09: Student Marks Matrix Analysis

Analyse a matrix of student marks across subjects, calculate row-wise and column-wise statistics, identify top performers, and detect subjects with low average performance.
