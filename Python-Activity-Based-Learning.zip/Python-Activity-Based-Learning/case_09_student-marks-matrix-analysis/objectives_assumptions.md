# Objectives
1. Calculate each student's total and average.
2. Calculate subject-wise averages.
3. Identify the top performer and subjects below the average threshold.

# Assumptions
- Rows represent students and columns represent subjects.
- All marks are from 0 to 100.
- A subject is flagged when its average is below 50.
- Top performer is the student with the highest total; first occurrence wins a tie.
