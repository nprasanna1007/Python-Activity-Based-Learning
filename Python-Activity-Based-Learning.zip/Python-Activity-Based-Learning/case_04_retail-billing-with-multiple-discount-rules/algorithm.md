# Algorithm
1. Start.
2. Read product, category, price, and quantity records.
3. Validate positive price and quantity.
4. Calculate subtotal.
5. Calculate eligible discount and cap it at Rs. 500.
6. Distribute discount proportionally across items.
7. Calculate category tax and final invoice total.
8. Display itemized invoice.
9. Stop.
