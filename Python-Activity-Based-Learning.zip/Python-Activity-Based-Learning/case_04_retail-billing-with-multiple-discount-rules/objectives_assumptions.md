# Objectives
1. Calculate line totals and category taxes.
2. Apply a threshold discount with a maximum cap.
3. Generate an itemized invoice and final total.

# Assumptions
- Electronics tax is 18%; grocery tax is 5%.
- A 10% discount applies when pre-tax subtotal is at least Rs. 2000.
- Total discount is capped at Rs. 500.
- Discount is applied before tax, proportionally to each item for calculating taxable values.
