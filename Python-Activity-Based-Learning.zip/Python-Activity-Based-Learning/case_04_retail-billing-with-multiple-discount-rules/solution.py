# Case Study 04: Retail Billing with Multiple Discount Rules
products = [
    ("Headphones", "electronics", 1500, 1),
    ("Notebook pack", "grocery", 300, 2),
    ("USB drive", "electronics", 800, 1),
]
tax_rates = {"electronics": 0.18, "grocery": 0.05}

subtotal = 0
for name, category, price, quantity in products:
    if category not in tax_rates or price < 0 or quantity <= 0:
        raise ValueError("Invalid product record")
    subtotal += price * quantity

discount = min(subtotal * 0.10, 500) if subtotal >= 2000 else 0
discount_rate = discount / subtotal if subtotal else 0
tax_total = 0

print("RETAIL INVOICE")
print("-" * 62)
for name, category, price, quantity in products:
    line_total = price * quantity
    taxable_value = line_total * (1 - discount_rate)
    tax = taxable_value * tax_rates[category]
    tax_total += tax
    print(f"{name:16} {quantity:>2} x Rs.{price:>7.2f} | Tax Rs.{tax:>7.2f}")

grand_total = subtotal - discount + tax_total
print("-" * 62)
print(f"Subtotal       : Rs. {subtotal:.2f}")
print(f"Discount       : Rs. {discount:.2f}")
print(f"Tax             : Rs. {tax_total:.2f}")
print(f"Grand total    : Rs. {grand_total:.2f}")
