# Test Cases

| Test | Expected result |
|---|---|
| Subtotal Rs. 2900 | Discount Rs. 290.00 |
| Electronics tax | 18% of discounted taxable value |
| Grocery tax | 5% of discounted taxable value |

## Expected summary
Subtotal Rs. 2900.00; discount Rs. 290.00; tax is calculated by category; final invoice includes subtotal minus discount plus tax.
