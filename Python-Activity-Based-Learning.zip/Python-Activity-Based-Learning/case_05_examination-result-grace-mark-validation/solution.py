# Case Study 05: Examination Result and Grace-Mark Validation
marks = [78, 36, 82, 69, 74]
pass_mark = 40
adjusted = marks.copy()
grace_used = 0

if any(mark < 0 or mark > 100 for mark in marks):
    print("Invalid marks: each mark must be between 0 and 100.")
else:
    failed = []
    for index, mark in enumerate(adjusted):
        if mark < pass_mark:
            failed.append(index)

    if len(failed) == 1:
        index = failed[0]
        shortfall = pass_mark - adjusted[index]
        if shortfall <= 5:
            adjusted[index] += shortfall
            grace_used = shortfall

    total = sum(adjusted)
    percentage = total / len(adjusted)
    passed = all(mark >= pass_mark for mark in adjusted)

    if not passed:
        classification = "FAIL"
    elif percentage >= 75:
        classification = "Distinction"
    elif percentage >= 60:
        classification = "First Class"
    elif percentage >= 50:
        classification = "Second Class"
    else:
        classification = "Pass"

    print("EXAMINATION RESULT")
    print("Original marks :", marks)
    print("Adjusted marks :", adjusted)
    print(f"Grace marks used: {grace_used}")
    print(f"Total marks     : {total}/{len(adjusted) * 100}")
    print(f"Percentage      : {percentage:.2f}%")
    print(f"Result          : {classification}")
