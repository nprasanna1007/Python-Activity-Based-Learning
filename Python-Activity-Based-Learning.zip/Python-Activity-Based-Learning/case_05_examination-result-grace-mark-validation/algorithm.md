# Algorithm
1. Start.
2. Read marks list.
3. Validate every mark is between 0 and 100.
4. Find failed subjects.
5. If exactly one subject is failed by 5 marks or less, apply the required grace marks.
6. Recalculate total and percentage.
7. Determine final pass/fail and class.
8. Display original and adjusted marks.
9. Stop.
