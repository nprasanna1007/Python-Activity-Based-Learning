# Case Study 05: Examination Result and Grace-Mark Validation

Process marks across multiple subjects, apply subject-wise pass criteria and a specified grace-mark policy, and generate final classifications without exceeding maximum marks.
