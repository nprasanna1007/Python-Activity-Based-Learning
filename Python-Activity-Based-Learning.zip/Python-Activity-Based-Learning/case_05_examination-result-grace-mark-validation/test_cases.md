# Test Cases

| Test | Expected result |
|---|---|
| Marks [78,36,82,69,74] | 36 is raised to 40 using 4 grace marks; percentage 68.60%; First Class |
| Any mark > 100 | Invalid marks message |
| Two failed subjects | No grace marks; FAIL |

## Expected summary
Adjusted marks [78, 40, 82, 69, 74], total 343/500, percentage 68.60%, First Class.
