# Objectives
1. Validate marks for each subject.
2. Apply a limited grace-mark policy where possible.
3. Calculate final total, percentage, and result classification.

# Assumptions
- Each subject is out of 100 and pass mark is 40.
- At most 5 grace marks may be added to one failed subject, only if that subject is short by 5 marks or less.
- Grace marks cannot make a subject exceed 100.
- Classification: Distinction >= 75%, First Class >= 60%, Second Class >= 50%, otherwise Pass if all subjects passed.
