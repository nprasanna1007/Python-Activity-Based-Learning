# Case Study 03: Employee Payroll and Deduction Analysis
basic_pay = 30000
overtime_hours = 8
incentive = 2000

if basic_pay < 0 or overtime_hours < 0:
    print("Invalid input: pay and overtime cannot be negative.")
else:
    hra = basic_pay * 0.20
    other_allowance = basic_pay * 0.10
    overtime_pay = (basic_pay / 160) * 1.5 * overtime_hours
    gross = basic_pay + hra + other_allowance + overtime_pay + incentive

    first_slab = min(gross, 20000) * 0.05
    second_slab = max(gross - 20000, 0) * 0.10
    deduction = first_slab + second_slab
    net_salary = gross - deduction

    print("EMPLOYEE SALARY STATEMENT")
    print(f"Basic pay       : Rs. {basic_pay:.2f}")
    print(f"HRA             : Rs. {hra:.2f}")
    print(f"Other allowance : Rs. {other_allowance:.2f}")
    print(f"Overtime pay    : Rs. {overtime_pay:.2f}")
    print(f"Incentive       : Rs. {incentive:.2f}")
    print(f"Gross salary    : Rs. {gross:.2f}")
    print(f"Deduction       : Rs. {deduction:.2f}")
    print(f"Net salary      : Rs. {net_salary:.2f}")
