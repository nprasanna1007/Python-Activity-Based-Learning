# Objectives
1. Calculate allowances, overtime, incentives, and gross pay.
2. Apply progressive deductions consistently.
3. Display net salary in a readable statement.

# Assumptions
- HRA is 20% of basic pay and other allowance is 10%.
- Overtime is paid at 1.5 times the hourly rate; hourly rate = basic pay / 160.
- Incentive is Rs. 2000.
- Deduction is 5% of the first Rs. 20000 gross and 10% of gross above Rs. 20000.
