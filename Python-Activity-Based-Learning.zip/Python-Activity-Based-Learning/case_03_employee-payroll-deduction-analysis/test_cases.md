# Test Cases

| Test | Expected result |
|---|---|
| Basic Rs. 30000, OT 8 hours | Gross Rs. 43250.00; deduction Rs. 3325.00; net Rs. 39925.00 |
| Negative basic pay | Invalid input message |

## Expected summary
Gross salary is Rs. 43250.00, deduction is Rs. 3325.00, and net salary is Rs. 39925.00.
