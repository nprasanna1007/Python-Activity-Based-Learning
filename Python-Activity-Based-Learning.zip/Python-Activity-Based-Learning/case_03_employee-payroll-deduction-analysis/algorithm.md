# Algorithm
1. Start.
2. Read basic pay and overtime hours.
3. Validate non-negative inputs.
4. Calculate allowances, overtime pay, and incentive.
5. Calculate gross salary.
6. Calculate progressive deduction.
7. Calculate net salary and print statement.
8. Stop.
