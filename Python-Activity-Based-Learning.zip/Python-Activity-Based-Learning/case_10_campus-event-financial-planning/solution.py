# Case Study 10: Campus Event Financial Planning
participants = 120
venue = 12000
equipment = 5000
transport = 6000
catering_per_person = 150
certificate_per_person = 20
sponsorship = 10000
contribution_per_person = 250

if participants < 0:
    print("Invalid participant count.")
else:
    fixed_cost = venue + equipment + transport
    variable_per_person = catering_per_person + certificate_per_person
    variable_cost = participants * variable_per_person
    total_cost = fixed_cost + variable_cost
    participant_income = participants * contribution_per_person
    total_income = sponsorship + participant_income
    balance = total_income - total_cost

    minimum_participants = 0
    while sponsorship + minimum_participants * contribution_per_person < fixed_cost + minimum_participants * variable_per_person:
        minimum_participants += 1

    print("CAMPUS EVENT FINANCIAL REPORT")
    print(f"Participants         : {participants}")
    print(f"Fixed costs          : Rs. {fixed_cost:.2f}")
    print(f"Variable costs       : Rs. {variable_cost:.2f}")
    print(f"Total cost           : Rs. {total_cost:.2f}")
    print(f"Sponsorship          : Rs. {sponsorship:.2f}")
    print(f"Participant income   : Rs. {participant_income:.2f}")
    print(f"Total income         : Rs. {total_income:.2f}")
    print(f"Surplus / shortfall  : Rs. {balance:.2f}")
    print(f"Break-even attendees : {minimum_participants}")
