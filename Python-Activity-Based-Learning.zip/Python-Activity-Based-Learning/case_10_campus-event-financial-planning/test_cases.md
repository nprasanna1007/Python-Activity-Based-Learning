# Test Cases

| Test | Expected result |
|---|---|
| 120 participants | Total cost Rs. 43400; total income Rs. 40000; shortfall Rs. 3400 |
| Break-even | Minimum 163 participants |
| Negative participants | Invalid participant count |

## Expected summary
For 120 attendees, total cost is Rs. 43400, total income is Rs. 40000, and shortfall is Rs. 3400. Break-even is 163 attendees.
