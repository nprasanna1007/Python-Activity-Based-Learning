# Objectives
1. Calculate total event expenditure.
2. Calculate the remaining amount after sponsorship.
3. Find minimum registrations needed to cover costs at a fixed contribution.

# Assumptions
- Costs are fixed: venue Rs. 12000, equipment Rs. 5000, transport Rs. 6000, certificates Rs. 20 per participant, and catering Rs. 150 per participant.
- Sponsorship is Rs. 10000.
- Each participant contributes Rs. 250.
- Break-even registrations are the smallest integer n where sponsorship + n*250 >= fixed costs + n*170.
