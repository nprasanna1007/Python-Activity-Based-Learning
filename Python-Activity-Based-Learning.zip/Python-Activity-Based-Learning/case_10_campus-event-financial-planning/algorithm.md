# Algorithm
1. Start.
2. Read expected participant count.
3. Validate non-negative count.
4. Calculate fixed and variable costs.
5. Calculate total cost, sponsorship, and participant contributions.
6. Calculate surplus or shortfall.
7. Calculate minimum registrations to break even.
8. Display financial report.
9. Stop.
